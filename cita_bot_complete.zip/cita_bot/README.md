# 🤖 Robot Cita 2.0 - Automatic Spain Immigration Appointment Bot

Ye Telegram bot automatically Spain ke ICP Clave website se immigration appointment book karta hai.

## 🚀 Features

- ✅ Sab provinces support (52 provinces)
- ✅ Sab tramites support (NIE, Renovacion, Carta Invitacion, etc.)
- ✅ Automatic form filling
- ✅ 24/7 monitoring (har 2-3 minute)
- ✅ Instant Telegram notification jab appointment mile
- ✅ Multiple searches simultaneously

## 📋 Setup Guide

### Step 1: Telegram Bot Token Banana

1. Telegram mein **@BotFather** search karo
2. `/newbot` likhو
3. Naam do (e.g., `MiCitaBot`)
4. Username do (e.g., `micita_bot`)
5. **Token copy karo** (format: `123456789:ABCdef...`)

### Step 2: Railway.app pe Deploy Karna (FREE)

1. **railway.app** pe jao
2. GitHub se sign up karo (free)
3. "New Project" click karo
4. "Deploy from GitHub repo" select karo
5. Is folder ko GitHub pe upload karo
6. Railway automatically deploy kar dega

### Step 3: Environment Variable Set Karo

Railway dashboard mein:
1. Apna project open karo
2. "Variables" tab pe jao
3. Add karo:
   - `TELEGRAM_BOT_TOKEN` = `aapka_token_yahaan`
   - `DATABASE_PATH` = `/app/cita_bot.db`

### Step 4: Bot Test Karo

Telegram mein apna bot search karo aur `/start` likhو

## 🔧 Local Setup (Testing ke liye)

```bash
# Install dependencies
pip install -r requirements.txt

# Install browser
playwright install chromium

# Environment variable set karo
export TELEGRAM_BOT_TOKEN="your_token_here"

# Run karo
python bot.py
```

## 📱 Bot Commands

| Command | Description |
|---------|-------------|
| `/start` | Bot start karo |
| `/nueva_busqueda` | Nayi appointment search |
| `/mis_busquedas` | Active searches dekho |
| `/cancelar` | Current operation cancel |
| `/ayuda` | Help |

## 🔄 Kaise Kaam Karta Hai

1. User `/nueva_busqueda` command deta hai
2. Bot tramite aur province choose karwata hai
3. Personal details (NIE, naam, phone, email) leta hai
4. Background mein ICP Clave website monitor karna shuru karta hai
5. Jab slot available ho:
   - Automatically form fill karta hai
   - Appointment book karta hai
   - User ko Telegram notification bhejta hai

## ⚠️ Important Notes

- Bot ko 24/7 running server chahiye (Railway free tier kaafi hai)
- ICP Clave website ka structure change hone pe bot ko update karna padega
- Multiple users simultaneously use kar sakte hain
- Search cancel karne ke liye `/mis_busquedas` se cancel button use karo

## 🛠️ Files Structure

```
cita_bot/
├── bot.py          # Main Telegram bot
├── scheduler.py    # ICP Clave monitoring + booking
├── database.py     # SQLite database
├── requirements.txt
├── railway.toml    # Railway deployment config
└── nixpacks.toml   # Build config
```

## 📞 Support

Koi problem? Bot ke /ayuda command se help lo.
