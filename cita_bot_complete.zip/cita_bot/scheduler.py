"""
Appointment Scheduler - ICP Clave website monitor karta hai
aur automatically appointment book karta hai
"""

import asyncio
import logging
import random
from datetime import datetime
from playwright.async_api import async_playwright
from database import Database

logger = logging.getLogger(__name__)

ICP_CLAVE_URL = "https://icp.administracionelectronica.gob.es/icpplus/index.html"


class AppointmentScheduler:
    def __init__(self):
        self.active_searches = {}  # search_id -> task
        self.db = Database()
        self.bot = None
    
    def add_search(self, search_id: int, user_id: int, data: dict, bot):
        """Add new search to monitor"""
        self.bot = bot
        task = asyncio.create_task(
            self._monitor_loop(search_id, user_id, data)
        )
        self.active_searches[search_id] = task
        logger.info(f"Search {search_id} monitoring shuru hua")
    
    def remove_search(self, search_id: int):
        """Remove search from monitoring"""
        if search_id in self.active_searches:
            self.active_searches[search_id].cancel()
            del self.active_searches[search_id]
    
    async def _monitor_loop(self, search_id: int, user_id: int, data: dict):
        """Main monitoring loop"""
        attempt = 0
        while True:
            attempt += 1
            logger.info(f"Search {search_id} - Attempt {attempt}")
            
            try:
                result = await self._check_and_book(search_id, user_id, data)
                
                if result['success']:
                    # Appointment booked!
                    self.db.mark_booked(search_id, result)
                    await self._notify_user(user_id, search_id, result, data)
                    break
                else:
                    # No slot found, wait and retry
                    wait_time = random.randint(120, 180)  # 2-3 minutes
                    logger.info(f"Search {search_id} - No slot. Waiting {wait_time}s")
                    await asyncio.sleep(wait_time)
                    
            except asyncio.CancelledError:
                logger.info(f"Search {search_id} cancelled")
                break
            except Exception as e:
                logger.error(f"Search {search_id} error: {e}")
                await asyncio.sleep(60)  # Wait 1 min on error
    
    async def _check_and_book(self, search_id: int, user_id: int, data: dict) -> dict:
        """Check ICP Clave for slots and book if available"""
        
        async with async_playwright() as p:
            # Launch browser (headless)
            browser = await p.chromium.launch(
                headless=True,
                args=['--no-sandbox', '--disable-setuid-sandbox']
            )
            
            context = await browser.new_context(
                viewport={'width': 1280, 'height': 720},
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            )
            
            page = await context.new_page()
            
            try:
                # Step 1: Go to ICP Clave
                await page.goto(ICP_CLAVE_URL, wait_until='networkidle', timeout=30000)
                
                # Step 2: Select provincia
                await page.select_option('#form', value=self._get_provincia_code(data['provincia']))
                await page.click('input[type="submit"]')
                await page.wait_for_load_state('networkidle')
                
                # Step 3: Accept terms
                try:
                    await page.click('#btnAceptar', timeout=5000)
                    await page.wait_for_load_state('networkidle')
                except:
                    pass
                
                # Step 4: Select tramite
                tramite_found = await self._select_tramite(page, data['tramite'])
                if not tramite_found:
                    return {'success': False, 'reason': 'tramite_not_found'}
                
                await page.click('input[type="submit"]')
                await page.wait_for_load_state('networkidle')
                
                # Step 5: Click "Solicitar Cita"
                try:
                    await page.click('#btnSolicitar', timeout=10000)
                    await page.wait_for_load_state('networkidle')
                except:
                    # Try alternative button
                    await page.click('input[value*="Solicitar"]', timeout=10000)
                    await page.wait_for_load_state('networkidle')
                
                # Step 6: Enter personal data
                await self._fill_personal_data(page, data)
                
                # Step 7: Check if slots available
                slot_available = await self._check_slots(page)
                
                if not slot_available:
                    return {'success': False, 'reason': 'no_slots'}
                
                # Step 8: Select first available slot
                appointment_details = await self._select_slot(page)
                
                # Step 9: Confirm booking
                await self._confirm_booking(page)
                
                return {
                    'success': True,
                    'fecha': appointment_details.get('fecha', 'N/A'),
                    'hora': appointment_details.get('hora', 'N/A'),
                    'oficina': appointment_details.get('oficina', 'N/A'),
                    'timestamp': datetime.now().isoformat()
                }
                
            except Exception as e:
                logger.error(f"Booking error: {e}")
                return {'success': False, 'reason': str(e)}
            finally:
                await browser.close()
    
    async def _select_tramite(self, page, tramite: str) -> bool:
        """Select the correct tramite from dropdown"""
        try:
            # Try to find tramite in select dropdown
            options = await page.query_selector_all('select option')
            for option in options:
                text = await option.inner_text()
                if any(word in text.upper() for word in tramite.upper().split()[:3]):
                    value = await option.get_attribute('value')
                    await page.select_option('select', value=value)
                    return True
            return False
        except Exception as e:
            logger.error(f"Tramite selection error: {e}")
            return False
    
    async def _fill_personal_data(self, page, data: dict):
        """Fill personal data form"""
        try:
            # NIE/Pasaporte
            nie_field = await page.query_selector('#dni')
            if nie_field:
                await nie_field.fill(data['nie'])
            
            # Nombre
            name_field = await page.query_selector('#nombre')
            if name_field:
                await name_field.fill(data['nombre'])
            
            # Año nacimiento (default 1990 if not set)
            year_field = await page.query_selector('#anio')
            if year_field:
                await year_field.fill(data.get('anio', '1990'))
            
            # Country - try to select
            try:
                await page.select_option('#pais', value='MARRUECOS')  # Default
            except:
                pass
            
            # Phone
            tel_field = await page.query_selector('#txtTelefono')
            if tel_field:
                phone = data['telefono'].replace('+34', '').replace(' ', '')
                await tel_field.fill(phone)
            
            # Email
            if data.get('email'):
                email_field = await page.query_selector('#txtCorreo')
                if email_field:
                    await email_field.fill(data['email'])
            
            # Submit form
            await page.click('input[type="submit"]')
            await page.wait_for_load_state('networkidle')
            
        except Exception as e:
            logger.error(f"Form fill error: {e}")
    
    async def _check_slots(self, page) -> bool:
        """Check if appointment slots are available"""
        try:
            # Check for "no hay citas" message
            content = await page.content()
            no_slots_messages = [
                'no hay citas disponibles',
                'no existen citas',
                'no quedan citas',
                'no hay plazas'
            ]
            
            for msg in no_slots_messages:
                if msg in content.lower():
                    return False
            
            # Check if calendar/slots exist
            calendar = await page.query_selector('.calendario, #calendario, table.cal')
            if calendar:
                return True
            
            # Check for date buttons
            date_buttons = await page.query_selector_all('a.celdaFecha, td.disponible')
            return len(date_buttons) > 0
            
        except Exception as e:
            logger.error(f"Slot check error: {e}")
            return False
    
    async def _select_slot(self, page) -> dict:
        """Select the first available slot"""
        details = {}
        
        try:
            # Click first available date
            date_links = await page.query_selector_all('a.celdaFecha, td.disponible a')
            if date_links:
                fecha_text = await date_links[0].inner_text()
                details['fecha'] = fecha_text.strip()
                await date_links[0].click()
                await page.wait_for_load_state('networkidle')
            
            # Click first available time slot
            time_slots = await page.query_selector_all('input[type="radio"], a.hora')
            if time_slots:
                hora_text = await time_slots[0].inner_text()
                details['hora'] = hora_text.strip()
                await time_slots[0].click()
            
            # Get oficina info
            oficina = await page.query_selector('.oficina, #oficina')
            if oficina:
                details['oficina'] = await oficina.inner_text()
                
        except Exception as e:
            logger.error(f"Slot selection error: {e}")
        
        return details
    
    async def _confirm_booking(self, page):
        """Confirm the appointment booking"""
        try:
            # Click confirm button
            confirm_buttons = [
                'input[value*="Confirmar"]',
                'input[value*="Aceptar"]',
                '#btnConfirmar',
                'input[type="submit"]'
            ]
            
            for selector in confirm_buttons:
                try:
                    await page.click(selector, timeout=3000)
                    await page.wait_for_load_state('networkidle')
                    break
                except:
                    continue
                    
        except Exception as e:
            logger.error(f"Confirmation error: {e}")
    
    def _get_provincia_code(self, provincia: str) -> str:
        """Get provincia code for ICP Clave dropdown"""
        # ICP Clave uses specific codes
        codes = {
            "A Coruña": "15", "Albacete": "02", "Alicante": "03",
            "Almería": "04", "Araba": "01", "Asturias": "33",
            "Ávila": "05", "Badajoz": "06", "Barcelona": "08",
            "Bizkaia": "48", "Burgos": "09", "Cáceres": "10",
            "Cádiz": "11", "Cantabria": "39", "Castellón": "12",
            "Ceuta": "51", "Ciudad Real": "13", "Córdoba": "14",
            "Cuenca": "16", "Gipuzkoa": "20", "Girona": "17",
            "Granada": "18", "Guadalajara": "19", "Huelva": "21",
            "Huesca": "22", "Illes Balears": "07", "Jaén": "23",
            "La Rioja": "26", "Las Palmas": "35", "León": "24",
            "Lleida": "25", "Lugo": "27", "Madrid": "28",
            "Málaga": "29", "Melilla": "52", "Murcia": "30",
            "Navarra": "31", "Ourense": "32", "Palencia": "34",
            "Pontevedra": "36", "Salamanca": "37",
            "Santa Cruz de Tenerife": "38", "Segovia": "40",
            "Sevilla": "41", "Soria": "42", "Tarragona": "43",
            "Teruel": "44", "Toledo": "45", "Valencia": "46",
            "Valladolid": "47", "Zamora": "49", "Zaragoza": "50"
        }
        return codes.get(provincia, "28")  # Default Madrid
    
    async def _notify_user(self, user_id: int, search_id: int, result: dict, data: dict):
        """Send notification to user about booked appointment"""
        if not self.bot:
            return
        
        message = (
            "🎉 *APPOINTMENT BOOK HO GAYI!*\n\n"
            f"✅ Search ID: {search_id}\n"
            f"📍 Provincia: {data['provincia']}\n"
            f"🔍 Tramite: {data['tramite'][:50]}...\n\n"
            f"📅 *Date:* {result.get('fecha', 'N/A')}\n"
            f"⏰ *Time:* {result.get('hora', 'N/A')}\n"
            f"🏢 *Oficina:* {result.get('oficina', 'N/A')}\n\n"
            "📧 Confirmation email check karo!\n\n"
            "_Congratulations! 🎊_"
        )
        
        try:
            await self.bot.send_message(
                chat_id=user_id,
                text=message,
                parse_mode='Markdown'
            )
        except Exception as e:
            logger.error(f"Notification error: {e}")
