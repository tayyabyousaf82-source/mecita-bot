"""
Robot Cita 2.0 - Automatic Appointment Booking Bot
Telegram bot jo ICP Clave website monitor karta hai aur automatically appointment book karta hai
"""

import os
import asyncio
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes, ConversationHandler
)
from database import Database
from scheduler import AppointmentScheduler

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Conversation states
SELECT_TRAMITE, SELECT_PROVINCIA, ENTER_NIE, ENTER_NAME, ENTER_PHONE, ENTER_EMAIL, CONFIRM = range(7)

# All Spanish provinces
PROVINCIAS = [
    "A Coruña", "Albacete", "Alicante", "Almería", "Araba", "Asturias",
    "Ávila", "Badajoz", "Barcelona", "Bizkaia", "Burgos", "Cáceres",
    "Cádiz", "Cantabria", "Castellón", "Ceuta", "Ciudad Real", "Córdoba",
    "Cuenca", "Gipuzkoa", "Girona", "Granada", "Guadalajara", "Huelva",
    "Huesca", "Illes Balears", "Jaén", "La Rioja", "Las Palmas", "León",
    "Lleida", "Lugo", "Madrid", "Málaga", "Melilla", "Murcia", "Navarra",
    "Ourense", "Palencia", "Pontevedra", "Salamanca", "Santa Cruz de Tenerife",
    "Segovia", "Sevilla", "Soria", "Tarragona", "Teruel", "Toledo",
    "Valencia", "Valladolid", "Zamora", "Zaragoza"
]

# All tramites
TRAMITES = [
    "TOMA DE HUELLAS (EXPEDICIÓN DE TARJETA)",
    "RENOVACIONES, PRÓRROGAS Y MODIFICACIONES",
    "CARTA DE INVITACIÓN",
    "CÉDULA DE INSCRIPCIÓN",
    "PRORROGA DE ESTANCIA CON VISADO",
    "PRORROGA DE ESTANCIA SIN VISADO",
    "SOLICITUD DE APATRIDA",
    "CERTIFICADOS CONCORDANCIA",
    "TÍTULOS DE VIAJE",
    "CERTIFICADOS Y ASIGNACION NIE",
    "SOLICITUD DE APATRIDA",
    "RECOGIDA DE TARJETA DE IDENTIDAD DE EXTRANJERO",
]

db = Database()
scheduler = AppointmentScheduler()


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Welcome message"""
    user = update.effective_user
    
    welcome_text = (
        f"🤖 *Bienvenido Robot Cita 2.0*, {user.first_name}!\n\n"
        "Main automatically aapke liye Spain mein immigration appointment book karta hoon.\n\n"
        "📋 *Main kya karta hoon:*\n"
        "• ICP Clave website continuously monitor karta hoon\n"
        "• Jab bhi appointment available ho, turant book karta hoon\n"
        "• Aapko Telegram pe notify karta hoon\n\n"
        "⚡ *Commands:*\n"
        "/nueva\\_busqueda - Nayi appointment search shuru karo\n"
        "/mis\\_busquedas - Apni active searches dekho\n"
        "/cancelar - Search cancel karo\n"
        "/estado - Account status dekho\n"
        "/ayuda - Help\n\n"
        "💡 Use /nueva\\_busqueda to get started!"
    )
    
    await update.message.reply_text(welcome_text, parse_mode='Markdown')


async def nueva_busqueda(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start new appointment search"""
    context.user_data.clear()
    
    # Show tramite selection
    keyboard = []
    for i, tramite in enumerate(TRAMITES):
        short_name = tramite[:40] + "..." if len(tramite) > 40 else tramite
        keyboard.append([InlineKeyboardButton(f"• {short_name}", callback_data=f"tramite_{i}")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "🔍 *Nayi Appointment Search*\n\n"
        "Pehle tramite (service type) select karo:",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )
    return SELECT_TRAMITE


async def select_tramite(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle tramite selection"""
    query = update.callback_query
    await query.answer()
    
    tramite_idx = int(query.data.split('_')[1])
    context.user_data['tramite'] = TRAMITES[tramite_idx]
    
    # Show provincia selection
    keyboard = []
    row = []
    for i, provincia in enumerate(PROVINCIAS):
        row.append(InlineKeyboardButton(provincia, callback_data=f"prov_{i}"))
        if len(row) == 3:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        f"✅ Tramite: *{context.user_data['tramite'][:50]}*\n\n"
        "📍 Ab provincia select karo:",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )
    return SELECT_PROVINCIA


async def select_provincia(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle provincia selection"""
    query = update.callback_query
    await query.answer()
    
    prov_idx = int(query.data.split('_')[1])
    context.user_data['provincia'] = PROVINCIAS[prov_idx]
    
    await query.edit_message_text(
        f"✅ Provincia: *{context.user_data['provincia']}*\n\n"
        "📝 Ab apna NIE/Pasaporte number bhejo:\n"
        "_(Example: X1234567A ya AB123456)_",
        parse_mode='Markdown'
    )
    return ENTER_NIE


async def enter_nie(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle NIE input"""
    nie = update.message.text.strip().upper()
    context.user_data['nie'] = nie
    
    await update.message.reply_text(
        f"✅ NIE/Pasaporte: *{nie}*\n\n"
        "👤 Apna poora naam bhejo:\n"
        "_(Example: Ahmed Ali Khan)_",
        parse_mode='Markdown'
    )
    return ENTER_NAME


async def enter_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle name input"""
    name = update.message.text.strip()
    context.user_data['nombre'] = name
    
    await update.message.reply_text(
        f"✅ Naam: *{name}*\n\n"
        "📱 Phone number bhejo (Spain format):\n"
        "_(Example: +34612345678)_",
        parse_mode='Markdown'
    )
    return ENTER_PHONE


async def enter_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle phone input"""
    phone = update.message.text.strip()
    context.user_data['telefono'] = phone
    
    await update.message.reply_text(
        f"✅ Phone: *{phone}*\n\n"
        "📧 Email address bhejo:\n"
        "_(Confirmation email yahaan aayega)_\n"
        "Ya 'skip' likhو agar nahi chahiye",
        parse_mode='Markdown'
    )
    return ENTER_EMAIL


async def enter_email(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle email input"""
    email = update.message.text.strip()
    if email.lower() == 'skip':
        email = ''
    context.user_data['email'] = email
    
    # Show confirmation
    data = context.user_data
    email_display = data.get('email') or 'Nahi diya'
    
    keyboard = [
        [InlineKeyboardButton("✅ Confirm - Search Shuru Karo!", callback_data="confirm_yes")],
        [InlineKeyboardButton("❌ Cancel", callback_data="confirm_no")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "📋 *Confirm karo apni details:*\n\n"
        f"🔍 Tramite: {data['tramite'][:50]}...\n"
        f"📍 Provincia: {data['provincia']}\n"
        f"🪪 NIE: {data['nie']}\n"
        f"👤 Naam: {data['nombre']}\n"
        f"📱 Phone: {data['telefono']}\n"
        f"📧 Email: {email_display}\n\n"
        "⚡ Bot automatically website monitor karega aur appointment milne pe book kar lega!",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )
    return CONFIRM


async def confirm_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Confirm and start search"""
    query = update.callback_query
    await query.answer()
    
    if query.data == "confirm_no":
        await query.edit_message_text("❌ Search cancel kar di. /nueva_busqueda se dobara shuru karo.")
        return ConversationHandler.END
    
    # Save to database
    user_id = update.effective_user.id
    search_id = db.save_search(user_id, context.user_data)
    
    # Start monitoring
    scheduler.add_search(search_id, user_id, context.user_data, query.bot)
    
    await query.edit_message_text(
        "🚀 *Search Shuru Ho Gayi!*\n\n"
        f"🆔 Search ID: `{search_id}`\n\n"
        "✅ Bot ab continuously ICP Clave website monitor kar raha hai.\n"
        "📲 Jab bhi appointment available hoga, main:\n"
        "1. Automatically book kar lunga\n"
        "2. Aapko yahaan notify karunga\n\n"
        "⏱️ Check interval: Har 2-3 minute\n\n"
        "📋 /mis_busquedas se status dekh sakte ho",
        parse_mode='Markdown'
    )
    return ConversationHandler.END


async def mis_busquedas(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user's active searches"""
    user_id = update.effective_user.id
    searches = db.get_user_searches(user_id)
    
    if not searches:
        await update.message.reply_text(
            "📭 Aapki koi active search nahi hai.\n"
            "Use /nueva_busqueda to start!"
        )
        return
    
    text = "📋 *Aapki Active Searches:*\n\n"
    keyboard = []
    
    for s in searches:
        status_emoji = "🟢" if s['status'] == 'active' else "🔴"
        text += (
            f"{status_emoji} *ID: {s['id']}*\n"
            f"  📍 {s['provincia']}\n"
            f"  🔍 {s['tramite'][:40]}...\n"
            f"  ⏱️ Status: {s['status']}\n\n"
        )
        keyboard.append([InlineKeyboardButton(
            f"❌ Cancel Search {s['id']}", 
            callback_data=f"cancel_{s['id']}"
        )])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')


async def cancel_search_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel a specific search"""
    query = update.callback_query
    await query.answer()
    
    search_id = int(query.data.split('_')[1])
    user_id = update.effective_user.id
    
    db.cancel_search(search_id, user_id)
    scheduler.remove_search(search_id)
    
    await query.edit_message_text(f"✅ Search {search_id} cancel kar di gayi.")


async def cancel_conversation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel current conversation"""
    context.user_data.clear()
    await update.message.reply_text(
        "❌ Operation cancel.\n"
        "Use /nueva_busqueda to start again."
    )
    return ConversationHandler.END


async def ayuda(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Help command"""
    await update.message.reply_text(
        "🤖 *Robot Cita 2.0 - Help*\n\n"
        "*Commands:*\n"
        "/start - Bot start karo\n"
        "/nueva\\_busqueda - Nayi appointment search\n"
        "/mis\\_busquedas - Apni searches dekho\n"
        "/cancelar - Current operation cancel karo\n"
        "/ayuda - Ye message\n\n"
        "*Kaise kaam karta hai:*\n"
        "1. /nueva\\_busqueda se details do\n"
        "2. Bot ICP Clave monitor karta hai\n"
        "3. Slot milne pe automatically book karta hai\n"
        "4. Confirmation aapko bhejta hai\n\n"
        "*Support:* Bot 24/7 kaam karta hai!",
        parse_mode='Markdown'
    )


def main():
    """Main function to run the bot"""
    token = os.environ.get('TELEGRAM_BOT_TOKEN')
    if not token:
        raise ValueError("TELEGRAM_BOT_TOKEN environment variable set nahi hai!")
    
    # Initialize database
    db.init()
    
    # Create application
    app = Application.builder().token(token).build()
    
    # Conversation handler
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('nueva_busqueda', nueva_busqueda)],
        states={
            SELECT_TRAMITE: [CallbackQueryHandler(select_tramite, pattern='^tramite_')],
            SELECT_PROVINCIA: [CallbackQueryHandler(select_provincia, pattern='^prov_')],
            ENTER_NIE: [MessageHandler(filters.TEXT & ~filters.COMMAND, enter_nie)],
            ENTER_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, enter_name)],
            ENTER_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, enter_phone)],
            ENTER_EMAIL: [MessageHandler(filters.TEXT & ~filters.COMMAND, enter_email)],
            CONFIRM: [CallbackQueryHandler(confirm_search, pattern='^confirm_')],
        },
        fallbacks=[CommandHandler('cancelar', cancel_conversation)],
    )
    
    # Add handlers
    app.add_handler(CommandHandler('start', start))
    app.add_handler(conv_handler)
    app.add_handler(CommandHandler('mis_busquedas', mis_busquedas))
    app.add_handler(CommandHandler('ayuda', ayuda))
    app.add_handler(CallbackQueryHandler(cancel_search_callback, pattern='^cancel_'))
    
    logger.info("🚀 Robot Cita 2.0 start ho gaya!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    main()
