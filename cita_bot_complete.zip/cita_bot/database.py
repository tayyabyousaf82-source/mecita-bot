"""
Database module - SQLite use karta hai searches store karne ke liye
"""

import sqlite3
import json
import os
from datetime import datetime


class Database:
    def __init__(self):
        self.db_path = os.environ.get('DATABASE_PATH', 'cita_bot.db')
    
    def init(self):
        """Initialize database tables"""
        with self._get_conn() as conn:
            conn.executescript('''
                CREATE TABLE IF NOT EXISTS searches (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    tramite TEXT NOT NULL,
                    provincia TEXT NOT NULL,
                    nie TEXT NOT NULL,
                    nombre TEXT NOT NULL,
                    telefono TEXT NOT NULL,
                    email TEXT,
                    status TEXT DEFAULT 'active',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    booked_at TIMESTAMP,
                    appointment_details TEXT
                );
                
                CREATE TABLE IF NOT EXISTS users (
                    telegram_id INTEGER PRIMARY KEY,
                    username TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                
                CREATE INDEX IF NOT EXISTS idx_searches_user ON searches(user_id);
                CREATE INDEX IF NOT EXISTS idx_searches_status ON searches(status);
            ''')
        print("✅ Database initialized!")
    
    def _get_conn(self):
        return sqlite3.connect(self.db_path)
    
    def save_search(self, user_id: int, data: dict) -> int:
        """Save new search and return search ID"""
        with self._get_conn() as conn:
            cursor = conn.execute('''
                INSERT INTO searches (user_id, tramite, provincia, nie, nombre, telefono, email)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                user_id,
                data['tramite'],
                data['provincia'],
                data['nie'],
                data['nombre'],
                data['telefono'],
                data.get('email', '')
            ))
            return cursor.lastrowid
    
    def get_user_searches(self, user_id: int) -> list:
        """Get all active searches for a user"""
        with self._get_conn() as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute('''
                SELECT * FROM searches 
                WHERE user_id = ? AND status = 'active'
                ORDER BY created_at DESC
            ''', (user_id,))
            return [dict(row) for row in cursor.fetchall()]
    
    def get_all_active_searches(self) -> list:
        """Get all active searches (for scheduler)"""
        with self._get_conn() as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute('''
                SELECT * FROM searches WHERE status = 'active'
            ''')
            return [dict(row) for row in cursor.fetchall()]
    
    def cancel_search(self, search_id: int, user_id: int):
        """Cancel a search"""
        with self._get_conn() as conn:
            conn.execute('''
                UPDATE searches SET status = 'cancelled'
                WHERE id = ? AND user_id = ?
            ''', (search_id, user_id))
    
    def mark_booked(self, search_id: int, appointment_details: dict):
        """Mark search as booked"""
        with self._get_conn() as conn:
            conn.execute('''
                UPDATE searches 
                SET status = 'booked', booked_at = ?, appointment_details = ?
                WHERE id = ?
            ''', (
                datetime.now().isoformat(),
                json.dumps(appointment_details),
                search_id
            ))
